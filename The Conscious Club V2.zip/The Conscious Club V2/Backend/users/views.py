from django.conf import settings
from django.core.mail import send_mail
from MailingList.models import MailingList
from django.views.generic import TemplateView
from .forms import UserForm
from django.shortcuts import render
from .models import Users


class HomeView(TemplateView):
    template_name = "users/index.html"

    def get(self, request):
        form = UserForm()
        users = Users.objects.all()

        context = {
            'form': form,
            'users': users
        }
        return render(request, self.template_name, context)

    def post(self, request):
        if request.method == 'POST':
            form = UserForm(request.POST)
            if form.is_valid():
                user = Users()
                user.username = form.cleaned_data['name']
                user.email = form.cleaned_data['email']
                user.is_volunteer = form.cleaned_data['volunteer']
                user.sub_mail = form.cleaned_data['mail']
                # send_mail('Welcome To Test Environment', 'MAIL TEST MAIL TEST MAIL TEST!!', settings.EMAIL_HOST_USER,
                #          [user.email], fail_silently=False)
                if user.sub_mail is True:
                    mailing_list = MailingList()
                    mailing_list.username = user.username
                    mailing_list.email = user.email
                    mailing_list.save()

                user.save()

        else:
            form = UserForm()

        return self.get(request)

