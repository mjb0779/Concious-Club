from django.contrib import admin
from .models import Users, MarketVendor


class UsersAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'is_volunteer', 'sub_mail')


class MarketVendorAdmin(admin.ModelAdmin):
    list_display = ('user', 'business_name', 'stall_description')


admin.site.register(Users, UsersAdmin)
admin.site.register(MarketVendor, MarketVendorAdmin)


