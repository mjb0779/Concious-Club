from django.db import models


class Users(models.Model):
    username = models.CharField(max_length=30)
    email = models.EmailField()
    is_volunteer = models.BooleanField(default=False)
    sub_mail = models.BooleanField(default=False)

    def __str__(self):
        return self.username

    class Meta:
        verbose_name_plural = "Users"


class MarketVendor(models.Model):
    user = models.ForeignKey(Users, on_delete=models.CASCADE)
    business_name = models.CharField(max_length=100)
    contact_number = models.CharField(max_length=13)
    stall_description = models.TextField()
    social_media = models.TextField(default="")

    def __str__(self):
        return self.business_name

    class Meta:
        verbose_name_plural = "Market Vendors"

