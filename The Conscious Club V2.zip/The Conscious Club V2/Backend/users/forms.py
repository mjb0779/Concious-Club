from django import forms


class UserForm(forms.Form):
    name = forms.CharField(widget=forms.TextInput(attrs={"class": "form-control"}))
    email = forms.EmailField(widget=forms.TextInput(attrs={"class": "form-control"}))
    volunteer = forms.BooleanField(widget=forms.CheckboxInput(attrs={"class": "form-control"}), required=False)
    mail = forms.BooleanField(widget=forms.CheckboxInput(attrs={"class": "form-control"}), required=False)

