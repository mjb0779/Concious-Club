from django.db import models
from datetime import datetime


class Events(models.Model):

    title = models.CharField(max_length=50)
    maori_title = models.CharField(max_length=100)
    place = models.CharField(max_length=50)
    content = models.TextField()
    maori_content = models.TextField()
    image = models.ImageField(upload_to='events_images', blank=True)
    schedule = models.DateTimeField(blank=True)
    created_on = models.DateTimeField(default=datetime.now(), blank=True)

    class Meta:
        verbose_name_plural = "Events"
