from django.contrib import admin
from .models import MailingList
# Register your models here.


class MailingListAdmin(admin.ModelAdmin):
    list_display = ('username', 'email')


admin.site.register(MailingList, MailingListAdmin)
