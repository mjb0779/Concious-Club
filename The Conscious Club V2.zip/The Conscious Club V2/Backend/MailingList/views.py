from django.shortcuts import render
from users.models import Users
from .models import MailingList
# Create your views here.


def index(request):

    users = Users.object.all()
    mailingList = MailingList()

    for user in users:
        if user.sub_mail is True:
            mailingList.username = user.username
            mailingList.email = user.email
            mailingList.save()

    return render(request)