from django.apps import AppConfig


class MailinglistConfig(AppConfig):
    name = 'MailingList'
