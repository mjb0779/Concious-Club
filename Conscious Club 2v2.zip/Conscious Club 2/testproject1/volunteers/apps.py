from django.apps import AppConfig


class VolunteersConfig(AppConfig):
    name = 'volunteers'
