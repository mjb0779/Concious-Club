from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index, name='index') # When the user loads post/ (initial page of post), the content will be views.index
]
