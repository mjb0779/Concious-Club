from django.db import models


class Volunteers(models.Model):
    name = models.CharField(max_length=20)
    email = models.EmailField(max_length=20)
    event = models.CharField(max_length=20) #could change depending on client answer to suggestion from char to event ID

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Volunteers"
