from django.conf.urls import url
from . import views
from django.urls import path, include

urlpatterns = [
    url(r'^$', views.index, name='index'), # When the user loads post/ (initial page of post), the content will be views.index
    url(r'details/(?P<id>\d+)/$', views.details, name='details')
]
