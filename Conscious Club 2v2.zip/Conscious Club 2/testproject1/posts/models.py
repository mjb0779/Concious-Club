from django.db import models
from datetime import datetime

# Create your models here.


class Posts(models.Model): # create Post Table - python manage.py makemigrations <tablename> -> python manage.py migrate
    title = models.CharField(max_length=20)
    body = models.TextField()
    created_at = models.DateTimeField(default=datetime.now(), blank=True)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name_plural = "Posts"
#
#
# class Admins(models.Model):
#     name = models.CharField(max_length=20)
#     user_name = models.CharField(max_length=10)
#     password = models.CharField(max_length=8) # look for hashing methods
#     email = models.EmailField(max_length=20)
#
#     class Meta:
#         verbose_name_plural = "Admins"
#
#
#
# class Vendors(models.Model):
#     name = models.CharField(max_length=20)
#     email = models.EmailField(max_length=20)
#     business_name = models.CharField(max_length=20)
#     product_type = models.CharField(max_length=20) #could be changed from char to product ID
#     phone_number = models.BigIntegerField()
#     social_media = models.URLField()
#
#     class Meta:
#         verbose_name_plural = "Vendors"
#
#
# class Products(models.Model):
#     name = models.CharField(max_length=20)
#     area = models.CharField(max_length=20)  # is this necessary?
#
#     class Meta:
#         verbose_name_plural = "Products"
